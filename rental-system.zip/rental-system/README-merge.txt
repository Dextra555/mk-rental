Merged Rental System plugin: Car & Yacht. Yacht uses car slider/wishlist JS & DB table.
