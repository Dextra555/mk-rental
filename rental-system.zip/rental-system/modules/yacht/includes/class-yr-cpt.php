<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class YR_CPT {
  public static function init(){ add_action('init',[__CLASS__,'register']); }
  public static function register(){
    register_post_type('yacht_rental',[
      'labels'=>['name'=>__('Yachts','yacht-rental'),'singular_name'=>__('Yacht','yacht-rental')],
      'public'=>true,'menu_icon'=>'dashicons-sos','supports'=>['title','editor','thumbnail','excerpt'],
      'has_archive'=>true,'rewrite'=>['slug'=>'yachts'],'show_in_rest'=>true
    ]);
    register_taxonomy('yacht_type','yacht_rental',[
      'labels'=>['name'=>__('Yacht Types','yacht-rental'),'singular_name'=>__('Yacht Type','yacht-rental')],
      'public'=>true,'hierarchical'=>true,'show_in_rest'=>true
    ]);
  }
}
YR_CPT::init();
