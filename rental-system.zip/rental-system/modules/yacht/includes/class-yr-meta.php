<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class YR_Meta {
  public static function init(){
    add_action('add_meta_boxes', [__CLASS__,'add_boxes']);
    add_action('save_post_yacht_rental', [__CLASS__,'save']);
  }
  public static function add_boxes(){
    add_meta_box('yr_specs', __('Yacht Specs','yacht-rental'), [__CLASS__,'box_specs'], 'yacht_rental','normal','default');
    add_meta_box('yr_pricing', __('Pricing & Availability','yacht-rental'), [__CLASS__,'box_price'], 'yacht_rental','side','default');
  }
  public static function get_meta($post_id){
    return [
      'pax' => get_post_meta($post_id,'yr_pax', true),
      'bedrooms' => get_post_meta($post_id,'yr_bedrooms', true),
      'length_ft' => get_post_meta($post_id,'yr_length_ft', true),
      'toilets' => get_post_meta($post_id,'yr_toilets', true),
      'price_hr' => get_post_meta($post_id,'yr_price_hr', true),
      'available' => get_post_meta($post_id,'yr_available', true),
      'gallery' => get_post_meta($post_id,'yr_gallery_ids', true),
    ];
  }
  public static function box_specs($post){
    wp_nonce_field('yr_save_meta','yr_meta_nonce');
    $m = self::get_meta($post->ID); ?>
    <table class="form-table">
      <tr><th><label><?php _e('No. of Persons (Pax)','yacht-rental');?></label></th><td><input type="number" min="1" name="yr_pax" value="<?php echo esc_attr($m['pax']);?>" /></td></tr>
      <tr><th><label><?php _e('No. of Bedrooms','yacht-rental');?></label></th><td><input type="number" min="0" name="yr_bedrooms" value="<?php echo esc_attr($m['bedrooms']);?>" /></td></tr>
      <tr><th><label><?php _e('Length (ft)','yacht-rental');?></label></th><td><input type="number" min="1" name="yr_length_ft" value="<?php echo esc_attr($m['length_ft']);?>" /></td></tr>
      <tr><th><label><?php _e('No. of Toilets','yacht-rental');?></label></th><td><input type="number" min="0" name="yr_toilets" value="<?php echo esc_attr($m['toilets']);?>" /></td></tr>
    </table>
    <hr/>
    <div class="yr-gallery-meta">
      <label style="display:block;margin-bottom:6px;"><strong><?php _e('Gallery Images','yacht-rental');?></strong></label>
      <input type="hidden" id="yr_gallery_ids" name="yr_gallery_ids" value="<?php echo esc_attr( is_array($m['gallery']) ? implode(',', $m['gallery']) : $m['gallery'] );?>"/>
      <div class="yr-gallery-thumbs" id="yr_gallery_thumbs">
        <?php
          $ids = is_array($m['gallery']) ? $m['gallery'] : array_filter(array_map('intval', explode(',', (string)$m['gallery'])));
          foreach($ids as $aid){
            $img = wp_get_attachment_image($aid, 'thumbnail');
            if ($img) echo '<span class="yr-thumb" data-id="'.esc_attr($aid).'">'.$img.'<b class="yr-remove" title="Remove">×</b></span>';
          }
        ?>
      </div>
      <button type="button" class="button" id="yr_gallery_pick"><?php _e('Select Images','yacht-rental');?></button>
      <button type="button" class="button" id="yr_gallery_clear"><?php _e('Clear','yacht-rental');?></button>
      <p class="description"><?php _e('Choose multiple images to display as a slider on the card.','yacht-rental');?></p>
    </div>
  <?php }
  public static function box_price($post){
    $m = self::get_meta($post->ID); ?>
    <p><label><?php _e('Price per hour (AED)','yacht-rental');?></label><br/>
    <input type="number" min="0" step="0.01" name="yr_price_hr" value="<?php echo esc_attr($m['price_hr']);?>" /></p>
    <p><strong><?php _e('Availability','yacht-rental');?></strong><br/>
      <label><input type="radio" name="yr_available" value="1" <?php checked($m['available'],'1');?>/> <?php _e('Available','yacht-rental');?></label>&nbsp;&nbsp;
      <label><input type="radio" name="yr_available" value="0" <?php checked($m['available'],'0');?>/> <?php _e('Not Available','yacht-rental');?></label>
    </p>
  <?php }
  public static function save($post_id){
    if ( ! isset($_POST['yr_meta_nonce']) || ! wp_verify_nonce($_POST['yr_meta_nonce'], 'yr_save_meta') ) return;
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;
    if ( ! current_user_can('edit_post', $post_id) ) return;
    foreach(['yr_pax','yr_bedrooms','yr_length_ft','yr_toilets'] as $k){
      if (isset($_POST[$k])) update_post_meta($post_id, $k, intval($_POST[$k]));
    }
    if (isset($_POST['yr_price_hr'])) update_post_meta($post_id,'yr_price_hr', floatval($_POST['yr_price_hr']));
    if ( isset($_POST['yr_available']) ) update_post_meta($post_id,'yr_available', $_POST['yr_available']==='1' ? '1' : '0');
    if ( isset($_POST['yr_gallery_ids']) ){
      $raw = sanitize_text_field($_POST['yr_gallery_ids']);
      $ids = array_filter(array_map('intval', explode(',', $raw)));
      update_post_meta($post_id, 'yr_gallery_ids', implode(',', $ids));
    }
  }
}
YR_Meta::init();
