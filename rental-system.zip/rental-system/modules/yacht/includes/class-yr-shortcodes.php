<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class YR_Shortcodes {
  public static function init(){
    add_shortcode('yacht_filter_form', [__CLASS__,'filter_form']);
    add_shortcode('yacht_grid', [__CLASS__,'grid']);
    add_shortcode('yacht_slider', [__CLASS__,'slider']);
    add_shortcode('yacht_login_button', [__CLASS__,'login_button']);
    add_shortcode('yacht_card', [__CLASS__,'card']);
    add_action('wp_ajax_yr_filter', [__CLASS__,'ajax_filter']);
    add_action('wp_ajax_nopriv_yr_filter', [__CLASS__,'ajax_filter']);
  }

  public static function login_button(){
    if ( is_user_logged_in() ) return '';
    return '<button class="yr-login-btn" data-yr-open-auth>❤ '.esc_html__('Sign in','yacht-rental').'</button>';
  }

  public static function filter_form($atts = []){
    $atts = shortcode_atts(['id'=>'','html_id'=>'','target'=>''], $atts, 'yacht_filter_form');
    $form_id = $atts['html_id'] ?: $atts['id'];
    $id_attr = $form_id ? ' id="'.esc_attr($form_id).'"' : '';
    $target = $atts['target'] ? ' data-yr-target="'. esc_attr($atts['target']) .'"' : '';
    $types = get_terms(['taxonomy'=>'yacht_type','hide_empty'=>false]);
    ob_start();
echo '<div class=\"yr-grid\">'; ?>
   <form class="yr-filter cr-filter-form" data-yr-filter<?php echo $id_attr; ?><?php echo $target; ?>>
  <div class="yr-field avil-cls">
    <label><?php esc_html_e('Yacht Type','yacht-rental');?></label>
    <select name="type">
      <option value=""><?php esc_html_e('Any','yacht-rental');?></option>
      <?php foreach($types as $t): ?>
        <option value="<?php echo esc_attr($t->term_id);?>"><?php echo esc_html($t->name);?></option>
      <?php endforeach; ?>
    </select>
  </div>

  <div class="yr-field avil-cls">
    <label><?php esc_html_e('Pax (min)','yacht-rental');?></label>
    <input type="number" name="pax" min="1" />
  </div>

  <div class="yr-field avil-cls">
    <label><?php esc_html_e('Availability','yacht-rental');?></label>
    <select name="available">
      <option value=""><?php esc_html_e('Any','yacht-rental');?></option>
      <option value="1"><?php esc_html_e('Available','yacht-rental');?></option>
      <option value="0"><?php esc_html_e('Unavailable','yacht-rental');?></option>
    </select>
  </div>

  <div class="yr-field avil-cls">
    <label><?php esc_html_e('Max Price (AED/hr)','yacht-rental');?></label>
    <input type="number" name="price_max" min="0" step="1" />
  </div>

  <!-- ✅ From Time -->
  <div class="yr-field">
    <label><?php esc_html_e('From Time','yacht-rental');?></label>
    <input type="time" name="from_time" />
  </div>

  <!-- ✅ To Time -->
  <div class="yr-field">
    <label><?php esc_html_e('To Time','yacht-rental');?></label>
    <input type="time" name="to_time" />
  </div>

  <button class="yr-btn cr-filter-btn" type="submit"><?php esc_html_e('Filter','yacht-rental');?></button>
  <button class="yr-btn yr-btn-outline" type="reset" data-yr-reset><?php esc_html_e('Reset','yacht-rental');?></button>
</form>

    <?php
    return ob_get_clean();
  }

  public static function grid($atts){
    // Always show yachts by default; 'id' is only the HTML id for the grid container.
    $atts = shortcode_atts(['per_page'=>9,'id'=>'','ids'=>''], $atts, 'yr_grid');
    $ids = [];
    if ( ! empty($atts['ids']) ) {
      $ids = array_map('intval', array_filter(array_map('trim', explode(',', $atts['ids']))));
    }
    $args = [
      'post_type' => 'yacht_rental',
      'posts_per_page' => intval($atts['per_page']),
      'post_status' => 'publish',
      'orderby' => 'date',
      'order' => 'DESC',
      'paged' => 1,
      'ignore_sticky_posts' => true,
    ];
    if ( ! empty($ids) ) {
      $args['post__in'] = array_unique($ids);
      $args['orderby'] = 'post__in';
      $args['posts_per_page'] = -1;
    }
    $q = new WP_Query($args);
    ob_start();
    echo '<div class="yr-grid" data-page="1" data-per-page="9" data-yr-grid id="'. esc_attr($atts['id']) .'" data-per-page="'.esc_attr($atts['per_page']).'">';
    while ( $q->have_posts() ) { $q->the_post();
      echo self::render_card(get_the_ID());
    }
    echo '</div>';
    if ( empty($ids) && $q->found_posts > $q->post_count ){
      echo '<div class="yr-load-more-wrap"><button class="button yr-load-more" data-target="'.($atts['id'] ? '#'.esc_attr($atts['id']) : '').'">'.esc_html__('Load more','yacht-rental').'</button></div>';
    }
    wp_reset_postdata();
    return ob_get_clean();
  }

public static function slider($atts) {
    $atts = shortcode_atts(['ids' => ''], $atts, 'yacht_slider');
    $args = [
        'post_type' => 'yacht_rental',
        'posts_per_page' => 6,
        'post_status' => 'publish'
    ];
    
    // Check if specific yacht IDs are provided
    if (!empty($atts['ids'])) {
        $arr = array_filter(array_map('intval', array_map('trim', explode(',', $atts['ids']))));
        if (!empty($arr)) {
            $args['post__in'] = $arr;
            $args['orderby'] = 'post__in';
            $args['posts_per_page'] = -1;
        }
    }
    
    // Query to get the yacht posts
    $q = new WP_Query($args);
    ob_start();
    
    // Slider HTML with SwiperJS classes for advanced functionality
    echo '<div class="yr-slider swiper-container" data-yr-slider>';
    echo '<div class="swiper-wrapper">';
    
    while ($q->have_posts()) {
        $q->the_post();
        echo '<div class="yr-slide swiper-slide">' . self::render_card(get_the_ID()) . '</div>';
    }
    
    echo '</div>'; // Close swiper-wrapper
    echo '<div class="swiper-pagination"></div>'; // Pagination for Swiper
    echo '<div class="swiper-button-next"></div>'; // Next button
    echo '<div class="swiper-button-prev"></div>'; // Prev button
    echo '</div>'; // Close swiper-container
    
    wp_reset_postdata();
    
    // SwiperJS initialization script (with autoplay, looping, and 3 slides by default)
    ?>
    <script>
        var swiper = new Swiper('.yr-slider', {
            loop: true,
            autoplay: {
                delay: 3000, // 3 seconds for autoplay
                disableOnInteraction: false,
            },
            slidesPerView: 3, // Display 3 slides at a time
            spaceBetween: 10, // Space between slides
            slidesPerGroup: 1, // Scroll 1 slide at a time
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
        });
    </script>
    <?php

    return ob_get_clean();
}



  public static function card($atts){
    $atts = shortcode_atts(['id'=>0], $atts, 'yacht_card');
    $post_id = intval($atts['id']);
    if ( ! $post_id ) return '';
    if ( get_post_type($post_id) !== 'yacht_rental') return '';
    return self::render_card($post_id);
  }

  public static function ajax_filter(){
    check_ajax_referer('yr_nonce','nonce');
    
    $paged = isset($_POST['paged']) ? max(1, intval($_POST['paged'])) : 1;
    $per = isset($_POST['per']) ? intval($_POST['per']) : 9;
    
    $tax_query = [];
    if ( !empty($_POST['type']) ) {
        $tax_query[] = ['taxonomy' => 'yacht_type', 'field' => 'term_id', 'terms' => intval($_POST['type'])];
    }

    $meta_query = ['relation' => 'AND'];
    if ( isset($_POST['pax']) && $_POST['pax'] !== '' ) {
        $meta_query[] = ['key' => 'yr_pax', 'value' => intval($_POST['pax']), 'type' => 'NUMERIC', 'compare' => '>='];
    }
    if ( isset($_POST['available']) && $_POST['available'] !== '' ) {
        $meta_query[] = ['key' => 'yr_available', 'value' => sanitize_text_field($_POST['available']) ];
    }
    if ( isset($_POST['price_max']) && $_POST['price_max'] !== '' ) {
        $meta_query[] = ['key' => 'yr_price_hr', 'value' => floatval($_POST['price_max']), 'type' => 'NUMERIC', 'compare' => '<='];
    }

    $args = [
        'post_type' => 'yacht_rental',
        'posts_per_page' => $per,
        'paged' => $paged,
        'tax_query' => $tax_query ?: null,
        'meta_query' => count($meta_query) > 1 ? $meta_query : null,
        'post_status' => 'publish'
    ];

    $q = new WP_Query($args);
    
    // Check if there are results
    if ($q->have_posts()) {
        ob_start();
        while($q->have_posts()) { $q->the_post();
            echo self::render_card(get_the_ID()); // Ensure this renders the yacht card correctly
        }
        echo '</div>';
$html = ob_get_clean();
        $has_more = ( $q->max_num_pages > $paged );
wp_send_json_success(['html' => $html, 'max' => $q->max_num_pages, 'found' => $q->found_posts, 'has_more' => $has_more]);
    } else {
        wp_send_json_error(['message' => 'No yachts found matching your filter criteria.']);
    }

    wp_reset_postdata();
}


  public static function render_card($post_id){
    $price = get_post_meta($post_id,'yr_price_hr',true);
    $pax = get_post_meta($post_id,'yr_pax',true);
    $beds = get_post_meta($post_id,'yr_bedrooms',true);
    $len = get_post_meta($post_id,'yr_length_ft',true);
    $toilets = get_post_meta($post_id,'yr_toilets',true);
    $available = get_post_meta($post_id,'yr_available',true);
    $is_available = ($available === '1');
    $gallery_raw = get_post_meta($post_id,'yr_gallery_ids',true);
    $gallery_ids = array_filter(array_map('intval', explode(',', (string)$gallery_raw)));
    $thumb_id = get_post_thumbnail_id($post_id);
    if ($thumb_id){ array_unshift($gallery_ids, $thumb_id); $gallery_ids = array_values(array_unique($gallery_ids)); }
    $wish_attr = ''; $in_wishlist = false; if ( is_user_logged_in() ){ $list = (array) CR_Wishlist::user_wishlist_ids(); $in_wishlist = in_array($post_id, $list, true); $wish_attr = $in_wishlist ? ' data-active="1"' : ''; }
    ob_start(); $lb_group = 'yr-'.$post_id; ?>
    <article class="yr-card" data-car="<?php echo esc_attr($post_id);?>">
      <div class="yr-media">
        <div class="cr-thumb-slider" data-index="0"><div class="cr-thumb-track">
          
            <?php if (!empty($gallery_ids)): foreach($gallery_ids as $gid): $full = wp_get_attachment_image_src($gid,'full'); ?>
              <div class="cr-thumb-slide">
                <a href="<?php echo esc_url($full ? $full[0] : ''); ?>" data-lightbox="<?php echo esc_attr($lb_group); ?>">
                  <?php echo wp_get_attachment_image($gid, 'large'); ?>
                </a>
              </div>
            <?php endforeach; else: ?>
              <div class="cr-thumb-slide"><?php echo get_the_post_thumbnail($post_id,'large'); ?></div>
            <?php endif; ?>
          </div><button class="cr-thumb-nav prev" aria-label="<?php esc_attr_e('Prev','yacht-rental'); ?>">&lt;</button><button class="cr-thumb-nav next" aria-label="<?php esc_attr_e('Next','yacht-rental'); ?>">&gt;</button><div class="cr-dots"></div></div>
        <?php if ( $price !== '' ): ?>
          <span class="yr-price cr-price"><?php echo esc_html__('AED ','yacht-rental') . '<strong>'. esc_html( number_format_i18n($price) ) .'</strong> /hr';?></span>
        <?php endif; ?>
        <button class="cr-heart" data-yr-wish<?php echo $wish_attr;?> aria-label="<?php esc_attr_e('Toggle wishlist','yacht-rental');?>"><span>♥</span></button>
        <?php if ( $is_available ): ?>
          <span class="yr-badge yr-badge--ok"><?php esc_html_e('Available','yacht-rental'); ?></span>
        <?php else: ?>
          <span class="yr-badge yr-badge--no"><?php esc_html_e('Not Available','yacht-rental'); ?></span>
        <?php endif; ?>
      </div>
      <div class="yr-body">
        <h3 class="yr-title cr-title"><a href="<?php the_permalink($post_id);?>"><?php echo esc_html( get_the_title($post_id) );?></a></h3>
        <div class="yr-specs">
          <span class="yr-spec"><?php echo self::ico('pax'); ?> <?php echo esc_html( $pax ?: '—'); ?> <?php esc_html_e('pax','yacht-rental');?></span>
          <span class="yr-spec"><?php echo self::ico('bed');?> <?php echo esc_html( $beds ?: '—'); ?> <?php esc_html_e('bedrooms','yacht-rental');?></span>
          <span class="yr-spec"><?php echo self::ico('ruler');?> <?php echo esc_html( $len ?: '—'); ?> <?php esc_html_e('ft','yacht-rental');?></span>
          <span class="yr-spec"><?php echo self::ico('bath');?> <?php echo esc_html( $toilets ?: '—'); ?> <?php esc_html_e('toilets','yacht-rental');?></span>
        </div>
      </div>
  
  <div class="button book-now">
  <button 
    class="open-booking-popup yr-btn"
    data-yacht-title="<?php echo esc_attr( get_the_title($post_id) ); ?>">
    <?php esc_html_e('Book Now', 'yacht-rental'); ?>
  </button>
</div>



    </article>
    <?php
    return ob_get_clean();
  }

  public static function ico($name){
    if ($name==='pax') return '<svg viewBox="0 0 24 24" class="yr-ico"><path d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4Zm-9 8a9 9 0 0 1 18 0z"/></svg>';
    if ($name==='bed') return '<svg viewBox="0 0 24 24" class="yr-ico"><path d="M3 10h18v6h-2v2h-2v-2H7v2H5v-2H3zM5 8h6a3 3 0 0 1 3 3H5z"/></svg>';
    if ($name==='ruler') return '<svg viewBox="0 0 24 24" class="yr-ico"><path d="M3 16.5 16.5 3 21 7.5 7.5 21zM7 14l3-3 2 2 3-3 2 2"/></svg>';
    if ($name==='bath') return '<svg viewBox="0 0 24 24" class="yr-ico"><path d="M3 13h18v3a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4zM7 7a3 3 0 0 1 6 0v6H7z"/></svg>';
    return '';
  }
}

YR_Shortcodes::init();

