<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class YR_Activator {
  public static function activate(){
    if ( class_exists('YR_CPT') ) YR_CPT::register();
    flush_rewrite_rules();
  }
}
