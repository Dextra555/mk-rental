
    <?php
    // Yacht wishlist system using Car's wishlist methods
    if ( ! defined( 'ABSPATH' ) ) exit;
    class YR_Wishlist extends CR_Wishlist {}
    