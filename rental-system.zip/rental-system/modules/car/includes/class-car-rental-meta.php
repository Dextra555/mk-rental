<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class CR_Meta {
    private $fields = [
        'seat_capacity'     => ['label'=>'Seat Capacity','type'=>'number'],
        'manufacturer_year' => ['label'=>'Manufacturer Year','type'=>'number'],
        'price_per_day'     => ['label'=>'Price per Day','type'=>'number','step'=>'0.01'],
        'zero_to_hundred'   => ['label'=>'0–100 km/h (seconds)','type'=>'number','step'=>'0.1'],
        'availability'      => ['label'=>'Availability','type'=>'radio','options'=>['Available','Not Available']],
    ];
    public function init(){
        add_action( 'add_meta_boxes', [ $this, 'add_meta_boxes' ] );
        add_action( 'save_post_car_rental', [ $this, 'save_meta' ] );
    }
    public function add_meta_boxes(){
        add_meta_box('cr_car_details',__('Car Details','car-rental'),[$this,'render_details'],'car_rental','normal','high');
        add_meta_box('cr_car_gallery',__('Car Gallery','car-rental'),[$this,'render_gallery'],'car_rental','normal','default');
    }
    public function render_details($post){
        wp_nonce_field('cr_save_meta','cr_meta_nonce');
        echo '<div class="cr-meta-grid">';
        foreach($this->fields as $key=>$cfg){
            $val = get_post_meta($post->ID,'_cr_'.$key,true);
            echo '<p><label><strong>'.esc_html($cfg['label']).'</strong></label><br/>';
            if($cfg['type']==='radio'){
                foreach($cfg['options'] as $opt){
                    printf('<label style="margin-right:12px;"><input type="radio" name="%1$s" value="%2$s" %3$s/> %2$s</label>',
                        esc_attr($key),esc_attr($opt),checked($val,$opt,false));
                }
            }else{
                $step = isset($cfg['step']) ? ' step="'.esc_attr($cfg['step']).'"' : '';
                printf('<input class="widefat" type="%1$s" name="%2$s" value="%3$s"%4$s/>',
                    esc_attr($cfg['type']),esc_attr($key),esc_attr($val),$step);
            }
            echo '</p>';
        }
        echo '</div>';
    }
    public function render_gallery($post){
        $gallery_ids = get_post_meta($post->ID,'_cr_gallery_ids',true);
        if(!is_array($gallery_ids)) $gallery_ids = [];
        echo '<div id="cr-gallery-wrapper">';
        echo '<button type="button" class="button" id="cr-add-gallery">'.esc_html__('Add/Update Gallery Images','car-rental').'</button>';
        echo '<ul id="cr-gallery-list">';
        foreach($gallery_ids as $id){
            $thumb = wp_get_attachment_image($id,[80,80]);
            echo '<li data-id="'.esc_attr($id).'">'.$thumb.'<span class="cr-remove">&times;</span></li>';
        }
        echo '</ul>';
        echo '<input type="hidden" name="cr_gallery_ids" id="cr_gallery_ids" value="'.esc_attr(implode(',',$gallery_ids)).'"/>';
        echo '</div>';
    }
    public function save_meta($post_id){
        if(!isset($_POST['cr_meta_nonce'])||!wp_verify_nonce($_POST['cr_meta_nonce'],'cr_save_meta')) return;
        if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if(!current_user_can('edit_post',$post_id)) return;
        foreach($this->fields as $key=>$cfg){
            if(isset($_POST[$key])){
                $val = sanitize_text_field(wp_unslash($_POST[$key]));
                update_post_meta($post_id,'_cr_'.$key,$val);
            }
        }
        if(isset($_POST['cr_gallery_ids'])){
            $ids = array_filter(array_map('absint',explode(',',sanitize_text_field(wp_unslash($_POST['cr_gallery_ids'])))));
            update_post_meta($post_id,'_cr_gallery_ids',$ids);
        }
    }
}
