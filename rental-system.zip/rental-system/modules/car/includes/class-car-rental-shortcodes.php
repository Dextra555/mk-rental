<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class CR_Shortcodes {
    public function init(){
        add_shortcode('car_filter_form',[$this,'filter_form']);
        add_shortcode('car_grid',[$this,'car_grid']);
        add_shortcode('car_slider',[$this,'car_slider']);
        add_shortcode('wishlist',[$this,'wishlist']);
        add_shortcode('car_login_button',[$this,'login_button']);
    }
    private function build_query_args($atts=[]){
        $atts = shortcode_atts(['posts_per_page'=>12], $atts);
        $meta_query = [];
        $tax_query = ['relation'=>'AND'];
        if(isset($_GET['seats']) && $_GET['seats']!==''){
            $meta_query[] = ['key'=>'_cr_seat_capacity','value'=>absint($_GET['seats']),'compare'=>'>=','type'=>'NUMERIC'];
        }
        if(isset($_GET['max_price']) && $_GET['max_price']!==''){
            $meta_query[] = ['key'=>'_cr_price_per_day','value'=>floatval($_GET['max_price']),'compare'=>'<=','type'=>'NUMERIC'];
        }
        if(isset($_GET['availability']) && in_array($_GET['availability'],['Available','Not Available'],true)){
            $meta_query[] = ['key'=>'_cr_availability','value'=>sanitize_text_field($_GET['availability']),'compare'=>'='];
        }
        if(isset($_GET['car_type']) && $_GET['car_type']!==''){
            $tax_query[] = ['taxonomy'=>'car_type','field'=>'slug','terms'=>sanitize_text_field($_GET['car_type'])];
        }
        if(isset($_GET['car_category']) && $_GET['car_category']!==''){
            $tax_query[] = ['taxonomy'=>'car_category','field'=>'slug','terms'=>sanitize_text_field($_GET['car_category'])];
        }
        $args = [
            'post_type'=>'car_rental',
            'posts_per_page'=>intval($atts['posts_per_page']),
            'post_status'=>'publish','meta_query'=>$meta_query
        ];
        if(count($tax_query)>1) $args['tax_query']=$tax_query;
        return $args;
    }
    public function filter_form($atts=[]){
        $atts = shortcode_atts(['target' => ''], $atts);
        $target_attr = $atts['target'] ? ' data-target="' . esc_attr($atts['target']) . '"' : '';
        $types = get_terms(['taxonomy'=>'car_type','hide_empty'=>false]);
        $cats  = get_terms(['taxonomy'=>'car_category','hide_empty'=>false]);
        ob_start(); ?>
        <form class="cr-filter-form" method="get"<?php echo $target_attr; ?>>
            <div class="cr-row">
                <div class="cr-field"><label><?php esc_html_e('Seats (min)','car-rental'); ?></label>
                    <input type="number" name="seats" min="1" value="<?php echo isset($_GET['seats']) ? esc_attr($_GET['seats']) : ''; ?>" />
                </div>
                <div class="cr-field"><label><?php esc_html_e('Max Price / Day','car-rental'); ?></label>
                    <input type="number" step="0.01" name="max_price" value="<?php echo isset($_GET['max_price']) ? esc_attr($_GET['max_price']) : ''; ?>" />
                </div>
                <div class="cr-field"><label><?php esc_html_e('Availability','car-rental'); ?></label>
                    <select name="availability">
                        <option value=""><?php esc_html_e('Any','car-rental'); ?></option>
                        <option value="Available" <?php selected(isset($_GET['availability'])?$_GET['availability']:'','Available'); ?>><?php esc_html_e('Available','car-rental'); ?></option>
                        <option value="Not Available" <?php selected(isset($_GET['availability'])?$_GET['availability']:'','Not Available'); ?>><?php esc_html_e('Not Available','car-rental'); ?></option>
                    </select>
                </div>
                <div class="cr-field"><label><?php esc_html_e('Type','car-rental'); ?></label>
                    <select name="car_type"><option value=""><?php esc_html_e('Any','car-rental'); ?></option>
                        <?php foreach($types as $t): ?><option value="<?php echo esc_attr($t->slug); ?>" <?php selected(isset($_GET['car_type'])?$_GET['car_type']:'',$t->slug); ?>><?php echo esc_html($t->name); ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="cr-field"><label><?php esc_html_e('Category','car-rental'); ?></label>
                    <select name="car_category"><option value=""><?php esc_html_e('Any','car-rental'); ?></option>
                        <?php foreach($cats as $c): ?><option value="<?php echo esc_attr($c->slug); ?>" <?php selected(isset($_GET['car_category'])?$_GET['car_category']:'',$c->slug); ?>><?php echo esc_html($c->name); ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="cr-field cr-submit">
                    <button type="submit" class="cr-filter-btn"><?php esc_html_e('Filter','car-rental'); ?></button>
                    <button type="button" class="cr-reset-btn"><?php esc_html_e('Reset','car-rental'); ?></button>
                </div>
            </div>
        </form>
        <?php return ob_get_clean();
    }
    private function render_card($post_id,$show_heart=true){
        $meta = [
            'seat_capacity'=>get_post_meta($post_id,'_cr_seat_capacity',true),
            'manufacturer_year'=>get_post_meta($post_id,'_cr_manufacturer_year',true),
            'price_per_day'=>get_post_meta($post_id,'_cr_price_per_day',true),
            'zero_to_hundred'=>get_post_meta($post_id,'_cr_zero_to_hundred',true),
            'availability'=>get_post_meta($post_id,'_cr_availability',true),
        ];
        $wishlist_ids = is_user_logged_in()? CR_Wishlist::user_wishlist_ids():[];
        $in_wishlist = in_array($post_id,$wishlist_ids,true);
        $gallery_ids = get_post_meta($post_id,'_cr_gallery_ids',true);
        if(!is_array($gallery_ids)) $gallery_ids = [];
        $thumb_id = get_post_thumbnail_id($post_id);
        if($thumb_id && !in_array($thumb_id,$gallery_ids,true)) array_unshift($gallery_ids,$thumb_id);
        ob_start(); ?>
        <div class="cr-card" data-car="<?php echo esc_attr($post_id); ?>">
            <div class="cr-thumb">
                <div class="cr-thumb-slider" data-index="0">
                    <div class="cr-thumb-track">
                        <?php if(!empty($gallery_ids)): foreach($gallery_ids as $img_id): ?>
                            <div class="cr-thumb-slide">
                                <a href="<?php echo esc_url(get_permalink($post_id)); ?>"><?php echo wp_get_attachment_image($img_id,'large'); ?></a>
<span class="cr-price"><?php echo esc_html__('AED ', 'car-rental') . '<strong>' . esc_html($meta['price_per_day']) . '</strong>' . ' /day'; ?></span>

                            </div>
                        <?php endforeach; else: ?>
                            <a href="<?php echo esc_url(get_permalink($post_id)); ?>"><?php echo get_the_post_thumbnail($post_id,'large'); ?></a>
                        <?php endif; ?>
                    </div>
                    <?php if(count($gallery_ids)>1): ?>
                        <button class="cr-thumb-nav prev" aria-label="<?php esc_attr_e('Prev image','car-rental'); ?>">&lt;</button>
                        <button class="cr-thumb-nav next" aria-label="<?php esc_attr_e('Next image','car-rental'); ?>">&gt;</button>
                        <div class="cr-dots">
                            <?php for($i=0;$i<count($gallery_ids);$i++): ?>
                                <button class="cr-dot <?php echo $i===0?'active':''; ?>" data-i="<?php echo esc_attr($i); ?>"></button>
                            <?php endfor; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <?php if($show_heart): ?>
                    <button class="cr-heart <?php echo $in_wishlist ? 'active':''; ?>" aria-label="<?php esc_attr_e('Wishlist','car-rental'); ?>"><span>&#9829;</span></button>
                <?php endif; ?>
            </div>
            <div class="cr-body">
                <h3 class="cr-title"><a href="<?php echo esc_url(get_permalink($post_id)); ?>"><?php echo esc_html(get_the_title($post_id)); ?></a></h3>
                <div class="cr-meta">
                   <span class="row-cs">
    <span class="titles"><?php echo esc_html__('Seats:', 'car-rental'); ?></span>
    <?php echo esc_html($meta['seat_capacity']); ?>
</span>

<span class="row-cs">
    <span class="titles"><?php echo esc_html__('Year:', 'car-rental'); ?></span>
    <?php echo esc_html($meta['manufacturer_year']); ?>
</span>
<span class="row-cs">
<span class="titles">Books:</span> 2
</span>
<span class="row-cs">
    <span class="titles"><?php echo esc_html__('0–100 km/h:', 'car-rental'); ?></span>
    <?php echo esc_html($meta['zero_to_hundred']); ?>s
</span>

                    <span class="cr-price mk-hide"><?php echo esc_html__('AED/Day:','car-rental').' '.esc_html($meta['price_per_day']); ?></span>
                    <span class=" mk-hide cr-badge <?php echo $meta['availability']==='Available'?'ok':'no'; ?>"><?php echo esc_html($meta['availability']); ?></span>
                </div>
                <div class="cr-excerpt"><?php echo wp_kses_post(get_the_excerpt($post_id)); ?></div>
            </div>
        </div>
        <?php return ob_get_clean();
    }
    public 
function car_grid($atts=[]){
    $atts = shortcode_atts(['id'=>'','posts_per_page'=>12], $atts);
    $grid_id_attr = $atts['id'] ? ' id="'.esc_attr($atts['id']).'"' : '';
    $pp = intval($atts['posts_per_page']); if($pp<=0) $pp=12;
    $args = $this->build_query_args($atts);
    $args['paged'] = 1;
    $args['posts_per_page'] = $pp;
    $q = new WP_Query($args);
    ob_start();
    echo '<div class="cr-grid" data-page="1" data-per-page="9"'.$grid_id_attr.' data-cr-grid data-page="1" data-per-page="'.esc_attr($pp).'">';
    if($q->have_posts()){ while($q->have_posts()){ $q->the_post(); echo $this->render_card(get_the_ID(),true);} wp_reset_postdata(); }
    else{ echo '<p>'.esc_html__('No cars found.','car-rental').'</p>'; }
    echo '</div>';
    // Load more button if there are more posts
    $total = $q->max_num_pages;
    if($total > 1){
        echo '<div class="cr-loadmore-wrap"><button class="button cr-load-more" data-target="'.($atts['id'] ? '#'.esc_attr($atts['id']) : '').'">'.esc_html__('Load more','car-rental').'</button></div>';
    }
    return ob_get_clean();
}

    public function car_slider($atts=[]){
        $atts = shortcode_atts(['posts_per_page'=>10],$atts);
        $q = new WP_Query(['post_type'=>'car_rental','posts_per_page'=>intval($atts['posts_per_page']),'post_status'=>'publish']);
        ob_start(); ?>
        <div class="cr-slider" data-visible="3">
            <button class="cr-nav prev" aria-label="<?php esc_attr_e('Prev','car-rental'); ?>">&lt;</button>
            <div class="cr-track">
                <?php if($q->have_posts()): while($q->have_posts()): $q->the_post(); ?>
                    <div class="cr-slide"><?php echo $this->render_card(get_the_ID(),true); ?></div>
                <?php endwhile; wp_reset_postdata(); endif; ?>
            </div>
            <button class="cr-nav next" aria-label="<?php esc_attr_e('Next','car-rental'); ?>">&gt;</button>
        </div>
        <?php return ob_get_clean();
    }
    public function wishlist(){
        if(!is_user_logged_in()) return '<p>'.esc_html__('Please log in to see your wishlist.','car-rental').'</p>';
        $ids = CR_Wishlist::user_wishlist_ids();
        if(empty($ids)) return '<p>'.esc_html__('Your wishlist is empty.','car-rental').'</p>';
        $q = new WP_Query(['post_type'=>'car_rental','post__in'=>$ids,'posts_per_page'=>-1]);
        ob_start();
        echo '<table class="cr-wishlist"><thead><tr>';
        echo '<th>'.esc_html__('Car','car-rental').'</th>';
        echo '<th>'.esc_html__('AED/Day','car-rental').'</th>';
        echo '<th>'.esc_html__('Seats','car-rental').'</th>';
        echo '<th>'.esc_html__('Year','car-rental').'</th>';
        echo '<th>'.esc_html__('Availability','car-rental').'</th>';
        echo '<th></th>';
        echo '</tr></thead><tbody>';
        if($q->have_posts()){
            while($q->have_posts()){ $q->the_post();
                $pid=get_the_ID(); $price=get_post_meta($pid,'_cr_price_per_day',true);
                $seats=get_post_meta($pid,'_cr_seat_capacity',true); $year=get_post_meta($pid,'_cr_manufacturer_year',true);
                $avail=get_post_meta($pid,'_cr_availability',true);
                echo '<tr data-car="'.$pid.'">';
                echo '<td><a href="'.esc_url(get_permalink()).'">'.esc_html(get_the_title()).'</a></td>';
                echo '<td>'.esc_html('AED '.$price).'</td>';
                echo '<td>'.esc_html($seats).'</td>';
                echo '<td>'.esc_html($year).'</td>';
                echo '<td>'.esc_html($avail).'</td>';
                echo '<td><button class="button cr-remove-from-wishlist" data-car="'.$pid.'">'.esc_html__('Remove','car-rental').'</button></td>';
                echo '</tr>';
            } wp_reset_postdata();
        }
        echo '</tbody></table>';
        return ob_get_clean();
    }
    public function login_button( $atts = [] ){
        $default = '[xoo_el_pop text="{pop}Login{/pop}" type="login" change_to_text="{logout}Logout?{/logout} {firstname}"]';
        $short = isset($atts['shortcode']) ? wp_kses_post( $atts['shortcode'] ) : $default;
        return do_shortcode( $short );
    }
public static function ajax_filter(){
    $paged = isset($_POST['paged']) ? max(1,intval($_POST['paged'])) : 1;
    $per   = isset($_POST['per']) ? max(1,intval($_POST['per'])) : 12;

    // Map posted filters into $_GET so build_query_args() can reuse them
    $map = ['seats','max_price','availability','car_type','car_category','s'];
    foreach($map as $k){
        if(isset($_POST[$k])) $_GET[$k]=sanitize_text_field( wp_unslash($_POST[$k]) );
    }

    $inst = new self();
    $args = $inst->build_query_args(['posts_per_page'=>$per]);
    $args['paged'] = $paged;

    $q = new WP_Query( $args );
    ob_start();
    echo '<div class="cr-grid" data-page="1" data-per-page="9" data-cr-grid data-page="'.esc_attr($paged).'" data-per-page="'.esc_attr($per).'">';
    if($q->have_posts()){
        while($q->have_posts()){ $q->the_post();
            echo $inst->render_card(get_the_ID(), true);
        }
        wp_reset_postdata();
    } else {
        echo '<p>'.esc_html__('No cars found.','car-rental').'</p>';
    }
    echo '</div>';
    $html = ob_get_clean();
    $has_more = $q->max_num_pages > $paged;
    wp_send_json_success(['html'=>$html,'has_more'=>$has_more,'next_page'=>$paged+1]);
}
}
