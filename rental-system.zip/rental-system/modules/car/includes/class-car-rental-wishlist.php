<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class CR_Wishlist {
    public function init(){
        add_action('wp_ajax_cr_toggle_wishlist',[$this,'toggle_wishlist']);
        add_action('wp_ajax_nopriv_cr_toggle_wishlist',[$this,'require_login']);
    }
    public function require_login(){
        wp_send_json_error(['message'=>__('Please log in to use wishlist.','car-rental')],403);
    }
    public function toggle_wishlist(){
        check_ajax_referer('cr_wishlist_nonce','nonce');
        if(!is_user_logged_in()) $this->require_login();
        $user_id = get_current_user_id();
        $car_id = isset($_POST['car_id']) ? absint($_POST['car_id']) : 0;
        if(!$car_id) wp_send_json_error(['message'=>'Invalid Car ID'],400);
        global $wpdb;
        $table = $wpdb->prefix.'car_rental_wishlist';
        $exists = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE user_id=%d AND car_id=%d",$user_id,$car_id));
        if($exists){
            $wpdb->delete($table,['user_id'=>$user_id,'car_id'=>$car_id],['%d','%d']);
            wp_send_json_success(['action'=>'removed']);
        }else{
            $wpdb->insert($table,['user_id'=>$user_id,'car_id'=>$car_id],['%d','%d']);
            wp_send_json_success(['action'=>'added']);
        }
    }
    public static function user_wishlist_ids($user_id=0){
        if(!$user_id) $user_id = get_current_user_id();
        global $wpdb;
        $table = $wpdb->prefix.'car_rental_wishlist';
        $ids = $wpdb->get_col($wpdb->prepare("SELECT car_id FROM $table WHERE user_id=%d",$user_id));
        return array_map('intval',$ids);
    }
}
