<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class CR_CPT {
    public function init(){
        add_action( 'init', [ $this, 'register_cpt' ] );
        add_action( 'init', [ $this, 'register_taxonomies' ] );
    }
    public function register_cpt(){
        register_post_type( 'car_rental', [
            'labels' => [
                'name' => __('Cars','car-rental'),
                'singular_name' => __('Car','car-rental'),
                'add_new_item' => __('Add New Car','car-rental'),
                'menu_name' => __('Car Rental','car-rental'),
            ],
            'public' => true,
            'has_archive' => true,
            'show_in_rest' => true,
            'menu_icon' => 'dashicons-car',
            'supports' => ['title','editor','thumbnail','excerpt'],
            'rewrite' => ['slug' => 'cars'],
        ]);
    }
    public function register_taxonomies(){
        register_taxonomy('car_type','car_rental',[
            'label'=>__('Car Types','car-rental'), 'public'=>true, 'hierarchical'=>true, 'show_in_rest'=>true, 'rewrite'=>['slug'=>'car-type']
        ]);
        register_taxonomy('car_category','car_rental',[
            'label'=>__('Car Categories','car-rental'), 'public'=>true, 'hierarchical'=>true, 'show_in_rest'=>true, 'rewrite'=>['slug'=>'car-category']
        ]);
    }
}
