(function($){
  $(function(){
    $('#cr-add-gallery').on('click',function(e){
      e.preventDefault();
      var frame=wp.media({title:'Select Gallery Images',button:{text:'Use these images'},library:{type:'image'},multiple:true});
      frame.on('select',function(){
        var ids=[], list=$('#cr-gallery-list').empty();
        frame.state().get('selection').each(function(att){ var a=att.toJSON(); ids.push(a.id); list.append('<li data-id="'+a.id+'"><img src="'+a.sizes.thumbnail.url+'"/><span class="cr-remove">&times;</span></li>'); });
        $('#cr_gallery_ids').val(ids.join(','));
      });
      frame.open();
    });
    $('#cr-gallery-list').on('click','.cr-remove',function(){ var $li=$(this).closest('li'); $li.remove();
      var ids=$('#cr-gallery-list li').map(function(){return $(this).data('id');}).get(); $('#cr_gallery_ids').val(ids.join(',')); });
  });
})(jQuery);
