
/* unified car+yacht front logic with AJAX + sliders */
function rsExtractGrid(htmlStr, selector){
  var tmp = document.createElement('div');
  tmp.innerHTML = htmlStr;
  var grid = tmp.querySelector(selector);
  if(!grid){
    var w = document.createElement('div');
    w.className = selector.replace('.','');
    w.innerHTML = htmlStr;
    return w.outerHTML;
  }
  return grid.outerHTML;
}

(function($){
  function showGridLoader($el){
    if(!$el || !$el.length) return;
    if(!$el.hasClass('rs-loading')){
      $el.addClass('rs-loading').append('<div class="rs-loader"><div class="rs-spinner"></div></div>');
    }
  }
  function hideGridLoader($el){
    if(!$el || !$el.length) return;
    $el.removeClass('rs-loading').find('> .rs-loader').remove();
  }

  window.initThumbSlider = function($el){
    if(!$el || !$el.length) return;
    if(typeof $.fn.slick !== 'function') return;
    if(!$el.hasClass('slick-initialized')){
      $el.slick({dots:true, arrows:false, infinite:true, autoplay:true, autoplaySpeed:2500, slidesToShow:1, slidesToScroll:1});
    }
  };
  function reinitSliders($ctx){ $ctx.find('.yr-thumb-slider, .cr-thumb-slider').each(function(){ initThumbSlider($(this)); }); }

  // CAR FILTER
  $(document).on('submit','.cr-filter-form', function(e){
    e.preventDefault();
    var $form = $(this);
    var data = $form.serializeArray();
    data.push({name:'action', value:'cr_filter_cars'});
    data.push({name:'nonce',  value:(window.CR_Ajax && CR_Ajax.nonce)||''});

    var targetSel = $form.attr('data-target') || $form.data('target') || '';
    var $grid = targetSel ? $(targetSel).first() : $form.nextAll('.cr-grid').first();
    if(!$grid.length) return;
    showGridLoader($grid);
    $.post((window.CR_Ajax && CR_Ajax.ajax_url)||'', data).done(function(res){
      if(res && res.success){
        var $tmp = $(rsExtractGrid(res.data.html, '.cr-grid'));
        var $newGrid = $tmp.hasClass('cr-grid') ? $tmp : $tmp.find('.cr-grid').first();
        $grid.html($newGrid.html());
        $grid.attr('data-page','1');
        var params={}; data.forEach(function(i){ params[i.name]=i.value; });
        $grid.data('last-params', params);
        reinitSliders($grid);
        var $btn = $('.cr-load-more[data-target="#'+$grid.attr('id')+'"]');
        if(res.data && res.data.has_more){ $btn.show(); } else { $btn.remove(); }
      }
    }).always(function(){ hideGridLoader($grid); });
  });

  // CAR LOAD MORE
  $(document).on('click','.cr-load-more', function(e){
    e.preventDefault();
    var $btn = $(this);
    var targetSel = $btn.attr('data-target') || '';
    var $grid = targetSel ? $(targetSel) : $btn.closest('.cr-loadmore-wrap').prevAll('.cr-grid').first();
    if(!$grid.length) return;
    var page = parseInt($grid.attr('data-page'),10) || 1;
    var per  = parseInt($grid.attr('data-per-page'),10) || 12;
    var params = $grid.data('last-params') || {};
    params.action = 'cr_load_more';
    params.paged  = page + 1;
    params.per    = per;
    params.nonce  = (window.CR_Ajax && CR_Ajax.nonce)||'';
    $btn.prop('disabled', true).addClass('is-loading');
    $.post((window.CR_Ajax && CR_Ajax.ajax_url)||'', params).done(function(res){
      if(res && res.success){
        var $tmp = $(rsExtractGrid(res.data.html, '.cr-grid'));
        var $chunk = $tmp.hasClass('cr-grid') ? $tmp.children() : $tmp.find('.cr-grid').first().children();
        if($chunk.length){
          $grid.append($chunk);
          $grid.attr('data-page', String(page+1));
          reinitSliders($grid);
        }
        if(!(res.data && res.data.has_more)){ $btn.remove(); }
      }
    }).always(function(){ $btn.prop('disabled', false).removeClass('is-loading'); });
  });

  // YACHT FILTER
  $(document).on('submit','.yr-filter-form', function(e){
    e.preventDefault();
    var $form = $(this);
    var data = $form.serializeArray();
    data.push({name:'action', value:'yr_filter'});
    data.push({name:'nonce',  value:(window.YR_Ajax && YR_Ajax.nonce)||''});
    var targetSel = $form.attr('data-target') || $form.data('target') || '';
    var $grid = targetSel ? $(targetSel).first() : $form.nextAll('.yr-grid').first();
    if(!$grid.length) return;
    showGridLoader($grid);
    $.post((window.YR_Ajax && YR_Ajax.ajax_url)||'', data).done(function(res){
      if(res && res.success){
        var $tmp = $(rsExtractGrid(res.data.html, '.yr-grid'));
        var $newGrid = $tmp.hasClass('yr-grid') ? $tmp : $tmp.find('.yr-grid').first();
        $grid.html($newGrid.html());
        $grid.attr('data-page','1');
        var params={}; data.forEach(function(i){ params[i.name]=i.value; });
        $grid.data('last-params', params);
        reinitSliders($grid);
        var $btn = $('.yr-load-more[data-target="#'+$grid.attr('id')+'"]');
        if(res.data && res.data.has_more){ $btn.show(); } else { $btn.remove(); }
      }
    }).always(function(){ hideGridLoader($grid); });
  });

  // YACHT LOAD MORE
  $(document).on('click','.yr-load-more', function(e){
    e.preventDefault();
    var $btn = $(this);
    var targetSel = $btn.attr('data-target') || '';
    var $grid = targetSel ? $(targetSel) : $btn.closest('.yr-load-more-wrap').prevAll('.yr-grid').first();
    if(!$grid.length) return;
    var page = parseInt($grid.attr('data-page'),10) || 1;
    var per  = parseInt($grid.attr('data-per-page'),10) || 9;
    var params = $grid.data('last-params') || {};
    params.action = 'yr_load_more';
    params.paged  = page + 1;
    params.per    = per;
    params.nonce  = (window.YR_Ajax && YR_Ajax.nonce)||'';
    $btn.prop('disabled', true).addClass('is-loading');
    $.post((window.YR_Ajax && YR_Ajax.ajax_url)||'', params).done(function(res){
      if(res && res.success){
        var $tmp = $(rsExtractGrid(res.data.html, '.yr-grid'));
        var $chunk = $tmp.hasClass('yr-grid') ? $tmp.children() : $tmp.find('.yr-grid').first().children();
        if($chunk.length){
          $grid.append($chunk);
          $grid.attr('data-page', String(page+1));
          reinitSliders($grid);
        }
        if(!(res.data && res.data.has_more)){ $btn.remove(); }
      }
    }).always(function(){ $btn.prop('disabled', false).removeClass('is-loading'); });
  });

})(jQuery);
