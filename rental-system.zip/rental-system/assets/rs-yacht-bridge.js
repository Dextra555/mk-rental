(function($){
  function reinitYachtSliders(ctx){
    var $ctx = ctx ? $(ctx) : $(document);
    $ctx.find('.yr-grid .cr-thumb-slider, .yr-grid .yr-thumb-slider').each(function(){
      if (typeof window.initThumbSlider === 'function') {
        window.initThumbSlider($(this));
      }
    });
  }
  $(document).ajaxSuccess(function(e, xhr, settings){
    try {
      if (!settings || !settings.data) return;
      var d = settings.data.toString();
      if (d.indexOf('action=yr_filter') === -1 && d.indexOf('action=yr_load_more') === -1) return;
      reinitYachtSliders(document);
    } catch(err){}
  });
  $(function(){ reinitYachtSliders(document); });
})(jQuery);
